-- HonorHelp.lua
-- Provides a dedicated help popup window for the Honor Bar addon.

local function color(c, s) return "|cff"..c..tostring(s).."|r" end
local hdr = function(s) return color("ffd200", s) end      -- gold
local cmd = function(s) return color("00c0ff", s) end      -- cyan
local dim = function(s) return color("aaaaaa", s) end      -- gray

local helpFrame

local function BuildHelpText()
  local lines = {}

  local function L(s) table.insert(lines, s) end
  local function blank() table.insert(lines, "") end

  L(hdr("Slash commands:"))
  L("  " .. cmd("/honor") .. " or " .. cmd("/hb") .. "  - open this help window")
  L("  " .. cmd("/honor config") .. "        - open the Bar Config window")
  L("  " .. cmd("/honor debug") .. "         - force honor refresh & print debug info")
  L("  " .. cmd("/honor cap <number>") .. "  - set weekly honor cap (e.g. /honor cap 750000)")
  L("  " .. cmd("/honor auto on|off") .. "   - toggle 1s auto-refresh")
  L("  " .. cmd("/honor resetpos") .. "      - reset bar position to screen center")
  L("  " .. cmd("/honor show|hide|toggle") .. " - show, hide, or toggle the bar")
  blank()
  L(dim("Legacy aliases:"))
  L("  " .. cmd("/honordebug") .. "          - same as /honor debug")
  L("  " .. cmd("/honorcap <number>") .. "   - same as /honor cap <number>")
  L("  " .. cmd("/honorauto on|off") .. "    - same as /honor auto on|off")
  L("  " .. cmd("/honorresetpos") .. "       - same as /honor resetpos")

  blank()
  L(hdr("!honor auto-reply:"))
  L("  " .. cmd("/hbreply on|off") .. "      - enable or disable replying to '!honor'")
  L("  When enabled, typing " .. cmd("!honor") .. " in chat replies with your weekly honor status.")

  blank()
  L(hdr("Pull timer:"))
  L("  " .. cmd("/honorpull [sec]") .. " or " .. cmd("/hbpull [sec]") .. " - start pull countdown (default 10s, range 2–30)")
  L("  " .. cmd("/cpull") .. "               - cancel the active pull timer")

  blank()
  L(hdr("Config checkboxes (in /honor config):"))
  L("  " .. cmd("Hide Bar Text") .. "        - hide the numbers/text on the bar")
  L("  " .. cmd("Only Numbers") .. "         - show compact numeric text only")
  L("  " .. cmd("Bar labels bottom") .. "    - show milestone labels below the bar instead of above")
  L("  " .. cmd("Hide Bar") .. "             - completely hide the bar frame")
  L("  " .. cmd("Hide Ticks") .. "           - hide tick marks on the bar")
  L("  " .. cmd("Enable !honor") .. "        - allow the addon to reply to '!honor'")
  L("  " .. cmd("Auto (Honor Cap)") .. "     - auto-set weekly cap from your current rank")
  L("  " .. cmd("Detach Stats") .. "          - show session stats in a movable transparent frame")

  blank()
  L(hdr("Config sliders / numeric inputs:"))
  L("  " .. cmd("Width") .. "                - bar width in pixels")
  L("  " .. cmd("Height") .. "               - bar height in pixels")
  L("  " .. cmd("Stats Refresh (s)") .. "    - seconds between honor/stats updates")
  L("  " .. cmd("Tick Width") .. "           - thickness of tick marks")
  L("  " .. cmd("Tick Amount") .. "          - number of tick marks on the bar (0–60)")
  L("  " .. cmd("Honor Cap") .. "            - manual weekly honor cap (disabled if Auto is on)")

  blank()
  L(hdr("Config color swatches:"))
  L("  " .. cmd("Bar Fill Color") .. "       - color of the bar itself")
  L("  " .. cmd("Tick Color") .. "           - color for normal tick marks")
  L("  " .. cmd("Milestone Color") .. "      - color for milestone tick marks")

  return table.concat(lines, "\n")
end

local function EnsureHelpFrame()
  if helpFrame and helpFrame:IsObjectType("Frame") then
    return helpFrame
  end

  local f = CreateFrame("Frame", "HonorBarHelpDialog", UIParent, "BasicFrameTemplateWithInset")
  helpFrame = f

  f:SetSize(520, 420)
  f:SetPoint("CENTER")
  f:SetMovable(true)
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)

  if UISpecialFrames then
    table.insert(UISpecialFrames, f:GetName())
  end

  -- Title
  local title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  title:SetPoint("LEFT", f.TitleBg or f, "LEFT", 10, 0)
  title:SetText("Honor Bar Help")

  -- Scroll frame
  local scroll = CreateFrame("ScrollFrame", "HonorBarHelpScrollFrame", f, "UIPanelScrollFrameTemplate")
  -- Anchor the scrollframe neatly inside the main frame so the scrollbar
  -- lines up visually under the close "X" button and within the borders.
  scroll:SetPoint("TOPLEFT", f, "TOPLEFT", 12, -32)
  scroll:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -32, 10)

  local content = CreateFrame("Frame", nil, scroll)
  content:SetSize(1, 1)
  scroll:SetScrollChild(content)

  local text = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  text:SetPoint("TOPLEFT")
  text:SetWidth(480)
  text:SetJustifyH("LEFT")
  text:SetJustifyV("TOP")

  local helpText = BuildHelpText()
  text:SetText(helpText)

  content:SetHeight(text:GetStringHeight() + 20)

  f.scroll = scroll
  f.content = content
  f.text = text

  f:Hide()

  return f
end

function HP_ShowHelpPopup()
  local f = EnsureHelpFrame()
  if f then
    f:Show()
    if f.scroll then
      f.scroll:SetVerticalScroll(0)
    end
  end
end

function HP_ToggleHelpDialog()
  local f = EnsureHelpFrame()
  if not f then return end
  if f:IsShown() then
    f:Hide()
  else
    HP_ShowHelpPopup()
  end
end