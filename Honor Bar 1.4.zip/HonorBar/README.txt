Honor Bar
==============
**Version:** 2.11i (Classic Era 11505)

About
-----
**Honor Bar** is a lightweight World of Warcraft Classic Era addon that tracks your **weekly honor** with a clean, movable progress bar. 
It auto-refreshes from the game APIs, shows **percentage and comma‑formatted values**, and provides a **live, session‑aware tooltip** 
(Honor/hour, ETA, Remaining to cap). Right‑click the bar for a compact menu with **cap, size, color, tick and visibility controls**. 
All settings persist between sessions.

What’s New (2.11i)
------------------
- Hotfix: removed a lingering Python‑style `elif` in the slash command handler. Everything is now proper Lua (`elseif`).

Features
--------
- **Weekly Honor bar** with percentage and comma‑formatted values.
- **Auto-refresh** honor every 1s (toggleable).
- **Live tooltip** (updates every 0.2s) showing:
  - Session Time
  - Honor/hour
  - Remaining to Cap
  - ETA to current cap
- **Right-click dropdown** with:
  - Lock/Unlock drag
  - **Set Honor Cap…** (custom dialog; OK applies immediately)
  - Change Fill Color (with opacity)
  - Width/Height controls (+/−, reset 300×30)
  - Show/Hide Bar
  - Ticks (5% markers) on/off, opacity, width
  - Toggle bar text (show/hide)
- **Persistent settings** saved between sessions:
  - Cap, position, size, color, auto-refresh, ticks, bar text, visibility.

Manual Commands
---------------
- `/honor` — help
- `/honor debug` — force honor update & print source API
- `/honor cap <number>` — set weekly cap (e.g., `750000` or `750,000` via dialog)
- `/honor auto on|off` — toggle 1s auto refresh
- `/honor lock on|off` — lock or unlock dragging
- `/honor resetpos` — reset bar to screen center
- `/honor show|hide|toggle` — show/hide the bar

Install
-------
1. Extract the **Honor Bar** folder into:
   `World of Warcraft/_classic_era_/Interface/AddOns/`
2. Enable the addon on the character select screen if needed.
3. If the addon doesn’t appear, enable **Load out of date AddOns** (or let me bump the Interface number for your client build).
4. `/reload` in-game after first install or updates.

Changelog
---------
**2.11i**
- Fix: convert lingering `elif` → `elseif` in slash handler; addon loads, commands work.

**2.11h**
- Hotfix for Lua syntax (bad `elif` → `elseif`) that blocked loading and commands.

**2.11g**
- README updated: added **About** section at the beginning (no code changes).

**2.11f**
- Add show/hide feature with slash commands and menu item; persist visibility.

**2.11d–e**
- Custom Set Cap dialog; removed reliance on StaticPopup; OK now applies immediately.

**2.11a–c / 2.11**
- Tooltip live refresh (0.2s), 5% ticks, size controls, color picker, saved settings.
